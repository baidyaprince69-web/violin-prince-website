from __future__ import annotations

import hashlib
import json
import os
import sqlite3
import tempfile
import unittest
import io
from contextlib import redirect_stdout
from unittest.mock import patch
from pathlib import Path

from phase3_release.github_handoff import prepare_releases, validate_phase2
from phase3_release import find_latest_ledger


def write_json(path: Path, payload: dict) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(payload, indent=2), encoding="utf-8")


class Phase3GitHubHandoffTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.root = Path(self.temp.name)
        self.phase2 = self.root / "phase2" / "output" / "motion-prototype"
        self.phase2.mkdir(parents=True)
        self.video = self.phase2 / "html-motion-prototype.mp4"
        self.video.write_bytes(b"synthetic-mp4-payload-for-unit-tests")
        self.video_sha = hashlib.sha256(self.video.read_bytes()).hexdigest()
        self.checked = "2026-11-13T16:40:53.107041+00:00"
        self.manifest = self.phase2 / "recovery-manifest.json"
        self.qc = self.phase2 / "quality-control-report.json"
        self.plan = self.root / "phase2" / "package" / "creative_plan.json"
        self.fingerprint = "a" * 64
        write_json(self.manifest, {
            "schema_version": 1,
            "package_fingerprint": self.fingerprint,
            "publishing_enabled": False,
            "stages": {
                "audio_mix": {
                    "status": "complete", "updated_at": self.checked,
                    "file": self.video.name, "output_sha256": self.video_sha,
                },
                "quality_control": {
                    "status": "passed", "updated_at": self.checked,
                    "report": self.qc.name, "checks_passed": 3, "checks_total": 3,
                },
            },
            "updated_at": self.checked,
        })
        write_json(self.qc, {
            "schema_version": 1,
            "checked_at": self.checked,
            "status": "passed", "passed": True,
            "video_file": self.video.name,
            "metrics": {"file_size_bytes": self.video.stat().st_size,
                        "duration_seconds": 24.0, "width": 720, "height": 1280},
            "checks": [
                {"name": "file_present", "passed": True},
                {"name": "video_stream_present", "passed": True},
                {"name": "audio_stream_present", "passed": True},
            ],
            "checks_passed": 3, "checks_total": 3,
            "failed_checks": [], "warnings": [],
        })
        write_json(self.plan, {
            "title": "Phase 3 handoff test",
            "narration_script": "A short test narration.",
            "hashtags": ["#ViolinPrince", "#Violin"],
        })
        self.database = self.root / "state" / "phase3-release-ledger.sqlite3"
        self.output = self.root / "output" / "phase3-release-handoff.json"
        self.kwargs = dict(
            phase2_root=self.phase2,
            creative_plan=self.plan,
            database=self.database,
            output=self.output,
            repository="baidyaprince69-web/violin-prince-website",
            handoff_run_id="10001",
            phase2_run_id="43463908965",
            artifact_name="v3-motion-prototype-43463908965",
            destinations=("youtube", "facebook", "instagram"),
        )
        self.original_publish_enabled = os.environ.get("PUBLISH_ENABLED")
        os.environ["PUBLISH_ENABLED"] = "false"

    def tearDown(self) -> None:
        if self.original_publish_enabled is None:
            os.environ.pop("PUBLISH_ENABLED", None)
        else:
            os.environ["PUBLISH_ENABLED"] = self.original_publish_enabled
        self.temp.cleanup()

    def test_exact_handoff_prepares_three_platform_records_without_provider_calls(self) -> None:
        before = hashlib.sha256(self.video.read_bytes()).hexdigest()
        report = prepare_releases(**self.kwargs)
        self.assertEqual(report["status"], "prepared")
        self.assertFalse(report["publishing_enabled"])
        self.assertEqual(report["provider_requests_made"], 0)
        self.assertEqual(report["phase2"]["qc_checks_passed"], 3)
        self.assertEqual(report["phase2"]["qc_checks_total"], 3)
        self.assertEqual(len(report["releases"]), 3)
        self.assertTrue(all(item["state"] == "READY" for item in report["releases"]))
        self.assertTrue(all(not item["existing_release_reused"] for item in report["releases"]))
        self.assertEqual(before, hashlib.sha256(self.video.read_bytes()).hexdigest())

    def test_repeated_handoff_reuses_release_ids_without_duplicate_rows(self) -> None:
        first = prepare_releases(**self.kwargs)
        second_kwargs = dict(self.kwargs, handoff_run_id="10002")
        second = prepare_releases(**second_kwargs)
        self.assertEqual(
            [item["release_id"] for item in first["releases"]],
            [item["release_id"] for item in second["releases"]],
        )
        self.assertTrue(all(item["existing_release_reused"] for item in second["releases"]))
        with sqlite3.connect(self.database) as connection:
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM release_records").fetchone()[0], 3)
            self.assertEqual(connection.execute("SELECT COUNT(*) FROM handoff_sources").fetchone()[0], 6)
            self.assertEqual(connection.execute("PRAGMA integrity_check").fetchone()[0], "ok")

    def test_manifest_and_qc_must_name_the_same_video(self) -> None:
        qc = json.loads(self.qc.read_text(encoding="utf-8"))
        qc["video_file"] = "different.mp4"
        write_json(self.qc, qc)
        with self.assertRaisesRegex(RuntimeError, "different MP4"):
            validate_phase2(self.phase2)

    def test_manifest_must_reference_the_actual_qc_report(self) -> None:
        manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
        manifest["stages"]["quality_control"]["report"] = "other-report.json"
        write_json(self.manifest, manifest)
        with self.assertRaisesRegex(RuntimeError, "different QC report"):
            validate_phase2(self.phase2)

    def test_modified_video_is_rejected(self) -> None:
        self.video.write_bytes(b"tampered-after-approval")
        with self.assertRaisesRegex(RuntimeError, "SHA-256"):
            validate_phase2(self.phase2)

    def test_failed_individual_qc_check_is_rejected(self) -> None:
        qc = json.loads(self.qc.read_text(encoding="utf-8"))
        qc["checks"][1]["passed"] = False
        write_json(self.qc, qc)
        with self.assertRaisesRegex(RuntimeError, "individual QC check failed"):
            validate_phase2(self.phase2)

    def test_inconsistent_qc_summary_counts_are_rejected(self) -> None:
        qc = json.loads(self.qc.read_text(encoding="utf-8"))
        qc["checks_passed"] = 2
        write_json(self.qc, qc)
        with self.assertRaisesRegex(RuntimeError, "summary counts"):
            validate_phase2(self.phase2)

    def test_qc_must_belong_to_same_manifest_timestamp_window(self) -> None:
        qc = json.loads(self.qc.read_text(encoding="utf-8"))
        qc["checked_at"] = "2026-11-14T16:40:53.107041+00:00"
        write_json(self.qc, qc)
        with self.assertRaisesRegex(RuntimeError, "timestamp does not belong"):
            validate_phase2(self.phase2)

    def test_artifact_path_traversal_is_rejected(self) -> None:
        manifest = json.loads(self.manifest.read_text(encoding="utf-8"))
        manifest["stages"]["audio_mix"]["file"] = "../../other.mp4"
        write_json(self.manifest, manifest)
        with self.assertRaisesRegex(RuntimeError, "escapes"):
            validate_phase2(self.phase2)

    def test_handoff_refuses_when_publishing_switch_is_on(self) -> None:
        os.environ["PUBLISH_ENABLED"] = "true"
        with self.assertRaisesRegex(RuntimeError, "must be false"):
            prepare_releases(**self.kwargs)

    def test_unknown_destination_is_rejected(self) -> None:
        kwargs = dict(self.kwargs, destinations=("metricool",))
        with self.assertRaisesRegex(ValueError, "Destinations"):
            prepare_releases(**kwargs)

    def test_report_and_ledger_do_not_store_video_bytes(self) -> None:
        report = prepare_releases(**self.kwargs)
        rendered = json.dumps(report)
        self.assertNotIn("synthetic-mp4-payload", rendered)
        self.assertLess(self.database.stat().st_size, 200_000)



class FindLatestLedgerTests(unittest.TestCase):
    def setUp(self) -> None:
        self.temp = tempfile.TemporaryDirectory()
        self.output = Path(self.temp.name) / "github-output.txt"
        self.env = patch.dict(os.environ, {
            "GITHUB_REPOSITORY": "baidyaprince69-web/violin-prince-website",
            "GH_TOKEN": "test-token",
            "GITHUB_RUN_ID": "current-run",
            "GITHUB_OUTPUT": str(self.output),
        }, clear=False)
        self.env.start()

    def tearDown(self) -> None:
        self.env.stop()
        self.temp.cleanup()

    def _artifact(self, run_id: str, *, expired: bool = False, created: str = "2026-11-13T16:00:00Z") -> dict:
        return {
            "name": "phase3-release-ledger", "expired": expired, "id": 123,
            "created_at": created, "workflow_run": {"id": run_id},
        }

    def test_no_prior_ledger_outputs_found_false(self) -> None:
        with patch.object(find_latest_ledger, "_get_artifacts", return_value=[]):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(find_latest_ledger.main(), 0)
        self.assertIn("found=false", self.output.read_text())

    def test_latest_prior_ledger_is_selected(self) -> None:
        artifacts = [
            self._artifact("old-run", created="2026-11-10T16:00:00Z"),
            self._artifact("new-run", created="2026-11-12T16:00:00Z"),
        ]
        with patch.object(find_latest_ledger, "_get_artifacts", return_value=artifacts):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(find_latest_ledger.main(), 0)
        output = self.output.read_text()
        self.assertIn("found=true", output)
        self.assertIn("run_id=new-run", output)

    def test_same_run_prior_attempt_ledger_is_not_ignored_on_retry(self) -> None:
        artifacts = [self._artifact("current-run")]
        with patch.object(find_latest_ledger, "_get_artifacts", return_value=artifacts):
            with redirect_stdout(io.StringIO()):
                self.assertEqual(find_latest_ledger.main(), 0)
        self.assertIn("found=true", self.output.read_text())
        self.assertIn("run_id=current-run", self.output.read_text())

    def test_expired_latest_ledger_fails_closed(self) -> None:
        artifacts = [self._artifact("expired-run", expired=True)]
        with patch.object(find_latest_ledger, "_get_artifacts", return_value=artifacts):
            with self.assertRaisesRegex(SystemExit, "expired"):
                find_latest_ledger.main()

    def test_api_error_never_initializes_an_empty_ledger(self) -> None:
        with patch.object(find_latest_ledger, "_get_artifacts", side_effect=RuntimeError("API unavailable")):
            with self.assertRaisesRegex(RuntimeError, "API unavailable"):
                find_latest_ledger.main()


if __name__ == "__main__":
    unittest.main()
