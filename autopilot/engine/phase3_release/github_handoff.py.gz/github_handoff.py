from __future__ import annotations

"""Validate a Phase 2 GitHub Actions artifact and prepare persistent Phase 3 releases.

This job is intentionally preparation-only. It never uploads or publishes video,
never instantiates a social client, and never changes or deletes the source MP4.
"""

import argparse
import hashlib
import json
import os
import re
import sqlite3
from datetime import datetime, timezone
from pathlib import Path
from typing import Any

SHA256_RE = re.compile(r"^[a-fA-F0-9]{64}$")
DESTINATIONS = {"youtube", "facebook", "instagram"}

SCHEMA = """
PRAGMA foreign_keys = ON;
CREATE TABLE IF NOT EXISTS release_records (
  release_id TEXT PRIMARY KEY,
  idempotency_key TEXT NOT NULL UNIQUE,
  artifact_id TEXT NOT NULL,
  package_fingerprint TEXT NOT NULL,
  video_sha256 TEXT NOT NULL,
  metadata_sha256 TEXT NOT NULL,
  destination TEXT NOT NULL CHECK(destination IN ('youtube','facebook','instagram')),
  state TEXT NOT NULL CHECK(state IN ('READY','SUBMISSION_STARTED','SUBMITTED','PROCESSING','SCHEDULED','PUBLISHED','NEEDS_RECONCILIATION','FAILED')),
  remote_id TEXT,
  remote_url TEXT,
  created_at TEXT NOT NULL,
  updated_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS release_events (
  event_id INTEGER PRIMARY KEY AUTOINCREMENT,
  release_id TEXT NOT NULL REFERENCES release_records(release_id),
  event_type TEXT NOT NULL,
  from_state TEXT,
  to_state TEXT NOT NULL,
  payload_json TEXT NOT NULL,
  created_at TEXT NOT NULL
);
CREATE TABLE IF NOT EXISTS handoff_sources (
  release_id TEXT NOT NULL REFERENCES release_records(release_id),
  handoff_run_id TEXT NOT NULL,
  phase2_run_id TEXT NOT NULL,
  source_artifact_name TEXT NOT NULL,
  source_repository TEXT NOT NULL,
  manifest_sha256 TEXT NOT NULL,
  qc_report_sha256 TEXT NOT NULL,
  video_sha256 TEXT NOT NULL,
  created_at TEXT NOT NULL,
  PRIMARY KEY(release_id, handoff_run_id, source_artifact_name)
);
CREATE INDEX IF NOT EXISTS idx_phase3_release_destination_state ON release_records(destination,state);
CREATE INDEX IF NOT EXISTS idx_phase3_handoff_source_run ON handoff_sources(phase2_run_id);
"""


def utc_now() -> str:
    return datetime.now(timezone.utc).isoformat(timespec="seconds").replace("+00:00", "Z")


def sha256_file(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest()


def read_json(path: Path, label: str) -> dict[str, Any]:
    try:
        value = json.loads(path.read_text(encoding="utf-8"))
    except (OSError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Cannot read {label}: {exc}") from exc
    if not isinstance(value, dict):
        raise RuntimeError(f"{label} must be a JSON object.")
    return value


def timestamp(value: Any, label: str) -> datetime:
    try:
        parsed = datetime.fromisoformat(str(value).replace("Z", "+00:00"))
    except (TypeError, ValueError) as exc:
        raise RuntimeError(f"{label} is missing or malformed.") from exc
    if parsed.tzinfo is None:
        raise RuntimeError(f"{label} must include a timezone.")
    return parsed.astimezone(timezone.utc)


def validate_phase2(phase2_root: Path) -> dict[str, Any]:
    root = phase2_root.resolve()
    manifest_path = root / "recovery-manifest.json"
    qc_path = root / "quality-control-report.json"
    if not manifest_path.is_file() or not qc_path.is_file():
        raise RuntimeError("Phase 2 artifact must contain recovery-manifest.json and quality-control-report.json.")

    manifest = read_json(manifest_path, "Phase 2 recovery manifest")
    qc = read_json(qc_path, "Phase 2 QC report")
    fingerprint = manifest.get("package_fingerprint")
    if not isinstance(fingerprint, str) or not SHA256_RE.fullmatch(fingerprint):
        raise RuntimeError("Phase 2 manifest has no valid package_fingerprint.")
    if manifest.get("publishing_enabled") is not False:
        raise RuntimeError("Phase 2 handoff test requires publishing_enabled=false.")

    stages = manifest.get("stages")
    if not isinstance(stages, dict):
        raise RuntimeError("Phase 2 recovery manifest has no stages object.")
    final = stages.get("audio_mix")
    qc_stage = stages.get("quality_control")
    if not isinstance(final, dict) or final.get("status") != "complete":
        raise RuntimeError("The final audio_mix render is not complete.")
    if not isinstance(qc_stage, dict) or qc_stage.get("status") != "passed":
        raise RuntimeError("Phase 2 quality-control stage has not passed.")
    if Path(str(qc_stage.get("report", ""))).name != qc_path.name:
        raise RuntimeError("Recovery manifest points to a different QC report.")

    relative_video = final.get("file")
    expected_hash = final.get("output_sha256")
    if not isinstance(relative_video, str) or not relative_video:
        raise RuntimeError("Final audio_mix stage does not name its MP4.")
    if not isinstance(expected_hash, str) or not SHA256_RE.fullmatch(expected_hash):
        raise RuntimeError("Final audio_mix stage does not contain a valid MP4 SHA-256.")
    video = (root / relative_video).resolve()
    try:
        video.relative_to(root)
    except ValueError as exc:
        raise RuntimeError("Recovery manifest MP4 path escapes the Phase 2 artifact directory.") from exc
    if not video.is_file() or video.suffix.lower() != ".mp4":
        raise RuntimeError("The approved MP4 is missing from the GitHub Actions artifact.")
    video_hash = sha256_file(video)
    if video_hash.lower() != expected_hash.lower():
        raise RuntimeError("Actual MP4 SHA-256 does not match the recovery manifest.")

    if qc.get("status") != "passed" or qc.get("passed") is not True:
        raise RuntimeError("QC report is not explicitly marked passed.")
    if Path(str(qc.get("video_file", ""))).name != video.name:
        raise RuntimeError("QC report refers to a different MP4.")
    checks = qc.get("checks")
    if not isinstance(checks, list) or not checks:
        raise RuntimeError("QC report has no individual checks.")
    if any(not isinstance(check, dict) or check.get("passed") is not True for check in checks):
        raise RuntimeError("At least one individual QC check failed or is malformed.")
    if qc.get("failed_checks") not in (None, []):
        raise RuntimeError("QC report includes failed_checks.")
    checks_total = int(qc.get("checks_total", len(checks)))
    checks_passed = int(qc.get("checks_passed", len(checks)))
    if checks_total != len(checks) or checks_passed != len(checks):
        raise RuntimeError("QC summary counts do not match the individual checks.")

    metrics = qc.get("metrics") if isinstance(qc.get("metrics"), dict) else {}
    if int(metrics.get("file_size_bytes", -1)) != video.stat().st_size:
        raise RuntimeError("QC file size does not match the actual MP4.")
    qc_updated = timestamp(qc_stage.get("updated_at"), "Manifest quality_control.updated_at")
    qc_checked = timestamp(qc.get("checked_at"), "QC checked_at")
    if abs((qc_updated - qc_checked).total_seconds()) > 300:
        raise RuntimeError("QC report timestamp does not belong to the manifest's final QC stage.")

    return {
        "manifest_path": manifest_path,
        "qc_path": qc_path,
        "video_path": video,
        "package_fingerprint": fingerprint.lower(),
        "video_sha256": video_hash.lower(),
        "manifest_sha256": sha256_file(manifest_path),
        "qc_report_sha256": sha256_file(qc_path),
        "qc_checks_passed": checks_passed,
        "qc_checks_total": checks_total,
        "duration_seconds": metrics.get("duration_seconds"),
        "width": metrics.get("width"),
        "height": metrics.get("height"),
        "video_size_bytes": video.stat().st_size,
        "manifest_publishing_enabled": False,
    }


def _metadata_fingerprint(plan: dict[str, Any]) -> tuple[str, dict[str, Any]]:
    metadata = {
        "title": str(plan.get("title") or "Violin Prince approved video").strip(),
        "description": str(plan.get("narration_script") or plan.get("description") or "").strip(),
        "hashtags": plan.get("hashtags", plan.get("tags", [])),
        "category": "MUSIC",
        "made_for_kids": False,
        "ai_disclosure": False,
    }
    if not isinstance(metadata["hashtags"], list):
        metadata["hashtags"] = []
    normalized = json.dumps(metadata, ensure_ascii=False, sort_keys=True, separators=(",", ":"))
    return hashlib.sha256(normalized.encode("utf-8")).hexdigest(), metadata


def prepare_releases(
    *,
    phase2_root: Path,
    creative_plan: Path,
    database: Path,
    output: Path,
    repository: str,
    handoff_run_id: str,
    phase2_run_id: str,
    artifact_name: str,
    destinations: tuple[str, ...],
) -> dict[str, Any]:
    if os.environ.get("PUBLISH_ENABLED", "false").strip().lower() in {"1", "true", "yes"}:
        raise RuntimeError("PUBLISH_ENABLED must be false for Phase 3 handoff. No publish request is allowed.")
    if not repository or not handoff_run_id or not phase2_run_id or not artifact_name:
        raise ValueError("Repository, handoff run ID, Phase 2 run ID and artifact name are required.")
    normalized = tuple(dict.fromkeys(str(item).strip().lower() for item in destinations))
    if not normalized or not set(normalized).issubset(DESTINATIONS):
        raise ValueError("Destinations must be selected from youtube, facebook and instagram.")

    artifact = validate_phase2(phase2_root)
    plan = read_json(creative_plan, "creative plan")
    metadata_sha, metadata = _metadata_fingerprint(plan)
    artifact_id = hashlib.sha256(
        f"{artifact['package_fingerprint']}:{artifact['video_sha256']}".encode("utf-8")
    ).hexdigest()

    database.parent.mkdir(parents=True, exist_ok=True)
    connection = sqlite3.connect(database, timeout=30, isolation_level=None)
    connection.row_factory = sqlite3.Row
    try:
        connection.execute("PRAGMA foreign_keys=ON")
        connection.execute("PRAGMA journal_mode=DELETE")
        connection.execute("PRAGMA synchronous=FULL")
        connection.executescript(SCHEMA)
        releases: list[dict[str, Any]] = []
        now = utc_now()
        connection.execute("BEGIN IMMEDIATE")
        try:
            for destination in normalized:
                key_payload = {
                    "artifact_id": artifact_id,
                    "destination": destination,
                    "metadata_sha256": metadata_sha,
                }
                key = hashlib.sha256(json.dumps(key_payload, sort_keys=True, separators=(",", ":")).encode("utf-8")).hexdigest()
                release_id = hashlib.sha256(key.encode("ascii")).hexdigest()[:32]
                existing = connection.execute(
                    "SELECT * FROM release_records WHERE idempotency_key=?", (key,)
                ).fetchone()
                created = existing is None
                if existing:
                    if (
                        existing["artifact_id"] != artifact_id
                        or existing["video_sha256"] != artifact["video_sha256"]
                        or existing["metadata_sha256"] != metadata_sha
                        or existing["destination"] != destination
                    ):
                        raise RuntimeError("A Phase 3 idempotency key maps to different video or destination data.")
                    row = dict(existing)
                else:
                    connection.execute(
                        """INSERT INTO release_records
                        (release_id,idempotency_key,artifact_id,package_fingerprint,video_sha256,
                         metadata_sha256,destination,state,created_at,updated_at)
                        VALUES (?,?,?,?,?,?,?,?,?,?)""",
                        (release_id,key,artifact_id,artifact["package_fingerprint"],artifact["video_sha256"],
                         metadata_sha,destination,"READY",now,now),
                    )
                    connection.execute(
                        "INSERT INTO release_events(release_id,event_type,from_state,to_state,payload_json,created_at) VALUES(?,?,?,?,?,?)",
                        (release_id,"phase2_approved_release_prepared",None,"READY",json.dumps({
                            "video_sha256": artifact["video_sha256"],
                            "manifest_sha256": artifact["manifest_sha256"],
                            "qc_report_sha256": artifact["qc_report_sha256"],
                            "qc_checks": f"{artifact['qc_checks_passed']}/{artifact['qc_checks_total']}",
                        },sort_keys=True),now),
                    )
                    row = dict(connection.execute("SELECT * FROM release_records WHERE release_id=?", (release_id,)).fetchone())

                connection.execute(
                    """INSERT OR IGNORE INTO handoff_sources
                    (release_id,handoff_run_id,phase2_run_id,source_artifact_name,source_repository,
                     manifest_sha256,qc_report_sha256,video_sha256,created_at)
                    VALUES (?,?,?,?,?,?,?,?,?)""",
                    (release_id,handoff_run_id,phase2_run_id,artifact_name,repository,
                     artifact["manifest_sha256"],artifact["qc_report_sha256"],artifact["video_sha256"],now),
                )
                releases.append({
                    "destination": destination,
                    "release_id": row["release_id"],
                    "state": row["state"],
                    "idempotency_key": row["idempotency_key"],
                    "existing_release_reused": not created,
                })
            connection.commit()
        except Exception:
            connection.rollback()
            raise

        integrity = connection.execute("PRAGMA integrity_check").fetchone()[0]
        if integrity != "ok":
            raise RuntimeError(f"Phase 3 SQLite integrity check failed: {integrity}")
        release_count = connection.execute("SELECT COUNT(*) FROM release_records").fetchone()[0]
        handoff_count = connection.execute("SELECT COUNT(*) FROM handoff_sources").fetchone()[0]
    finally:
        connection.close()

    report = {
        "schema_version": 1,
        "phase": "phase3_release_handoff",
        "status": "prepared",
        "publishing_enabled": False,
        "provider_requests_made": 0,
        "source": {
            "repository": repository,
            "handoff_run_id": str(handoff_run_id),
            "phase2_run_id": str(phase2_run_id),
            "artifact_name": artifact_name,
        },
        "phase2": {
            "package_fingerprint": artifact["package_fingerprint"],
            "video_file": artifact["video_path"].name,
            "video_sha256": artifact["video_sha256"],
            "video_size_bytes": artifact["video_size_bytes"],
            "manifest_sha256": artifact["manifest_sha256"],
            "qc_report_sha256": artifact["qc_report_sha256"],
            "qc_checks_passed": artifact["qc_checks_passed"],
            "qc_checks_total": artifact["qc_checks_total"],
            "duration_seconds": artifact["duration_seconds"],
            "width": artifact["width"],
            "height": artifact["height"],
        },
        "ledger": {
            "database": str(database),
            "sqlite_integrity_check": integrity,
            "release_count": release_count,
            "handoff_record_count": handoff_count,
        },
        "metadata_sha256": metadata_sha,
        "releases": releases,
    }
    output.parent.mkdir(parents=True, exist_ok=True)
    temp = output.with_suffix(output.suffix + ".tmp")
    temp.write_text(json.dumps(report, indent=2, ensure_ascii=False), encoding="utf-8")
    os.replace(temp, output)
    return report


def main() -> int:
    parser = argparse.ArgumentParser(description="Phase 3 GitHub Actions handoff: validate and record approved videos, never publish.")
    parser.add_argument("--phase2-root", required=True, type=Path)
    parser.add_argument("--creative-plan", required=True, type=Path)
    parser.add_argument("--database", required=True, type=Path)
    parser.add_argument("--output", required=True, type=Path)
    parser.add_argument("--repository", required=True)
    parser.add_argument("--handoff-run-id", required=True)
    parser.add_argument("--phase2-run-id", required=True)
    parser.add_argument("--artifact-name", required=True)
    parser.add_argument("--destinations", default="youtube,facebook,instagram")
    args = parser.parse_args()
    report = prepare_releases(
        phase2_root=args.phase2_root,
        creative_plan=args.creative_plan,
        database=args.database,
        output=args.output,
        repository=args.repository,
        handoff_run_id=args.handoff_run_id,
        phase2_run_id=args.phase2_run_id,
        artifact_name=args.artifact_name,
        destinations=tuple(part.strip() for part in args.destinations.split(",") if part.strip()),
    )
    print(json.dumps(report, indent=2, ensure_ascii=False))
    return 0


if __name__ == "__main__":
    raise SystemExit(main())
