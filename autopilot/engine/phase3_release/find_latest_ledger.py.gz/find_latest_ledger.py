from __future__ import annotations

"""Locate the latest non-expired Phase 3 state artifact in this repository."""

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request
from datetime import datetime
from typing import Any


def _emit(values: dict[str, str]) -> None:
    output = os.environ.get("GITHUB_OUTPUT")
    line = "".join(f"{key}={value}\n" for key, value in values.items())
    if output:
        with open(output, "a", encoding="utf-8") as handle:
            handle.write(line)
    print(line, end="")


def _get_artifacts(repository: str, token: str, artifact_name: str) -> list[dict[str, Any]]:
    api_base = os.environ.get("GITHUB_API_URL", "https://api.github.com").rstrip("/")
    query = urllib.parse.urlencode({"name": artifact_name, "per_page": 100})
    url = f"{api_base}/repos/{repository}/actions/artifacts?{query}"
    request = urllib.request.Request(
        url,
        headers={
            "Accept": "application/vnd.github+json",
            "Authorization": f"Bearer {token}",
            "X-GitHub-Api-Version": "2022-11-28",
            "User-Agent": "violin-prince-phase3-release-ledger",
        },
    )
    try:
        with urllib.request.urlopen(request, timeout=30) as response:
            payload = json.loads(response.read().decode("utf-8"))
    except (urllib.error.URLError, TimeoutError, json.JSONDecodeError) as exc:
        raise RuntimeError(f"Could not inspect existing Phase 3 ledger artifacts; refusing to start with an empty ledger: {exc}") from exc
    artifacts = payload.get("artifacts")
    if not isinstance(artifacts, list):
        raise RuntimeError("GitHub returned an invalid artifact listing; refusing to initialize an empty ledger.")
    return [item for item in artifacts if isinstance(item, dict) and item.get("name") == artifact_name]


def main() -> int:
    repository = os.environ.get("GITHUB_REPOSITORY", "").strip()
    token = (os.environ.get("GH_TOKEN") or os.environ.get("GITHUB_TOKEN") or "").strip()
    artifact_name = os.environ.get("PHASE3_LEDGER_ARTIFACT_NAME", "phase3-release-ledger").strip()
    if not repository or not token:
        raise SystemExit("GITHUB_REPOSITORY and GH_TOKEN are required to restore Phase 3 state safely.")

    artifacts = _get_artifacts(repository, token, artifact_name)
    previous = artifacts
    if not previous:
        _emit({"found": "false", "run_id": "", "artifact_id": "", "created_at": ""})
        print("No earlier Phase 3 ledger artifact exists; a new ledger will be initialized.")
        return 0

    previous.sort(key=lambda item: str(item.get("created_at", "")), reverse=True)
    latest = previous[0]
    if latest.get("expired") is True:
        raise SystemExit(
            "The latest Phase 3 ledger artifact has expired. Refusing to initialize a blank ledger, "
            "because doing so could forget earlier uploads and permit duplicates. Restore a saved ledger before continuing."
        )
    run_id = str(latest.get("workflow_run", {}).get("id", "")).strip()
    artifact_id = str(latest.get("id", "")).strip()
    created_at = str(latest.get("created_at", "")).strip()
    if not run_id or not artifact_id or not created_at:
        raise SystemExit("The latest Phase 3 ledger artifact is missing its run ID, artifact ID, or timestamp.")
    try:
        datetime.fromisoformat(created_at.replace("Z", "+00:00"))
    except ValueError as exc:
        raise SystemExit("The latest Phase 3 ledger artifact has an invalid creation timestamp.") from exc

    _emit({"found": "true", "run_id": run_id, "artifact_id": artifact_id, "created_at": created_at})
    print(f"Restoring the latest Phase 3 ledger snapshot from Actions run {run_id} ({created_at}).")
    return 0


if __name__ == "__main__":
    try:
        raise SystemExit(main())
    except Exception as exc:
        print(f"::error::{exc}", file=sys.stderr)
        raise
